from PIL import Image, ImageEnhance

image = Image.open("2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG")

vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

enhanced_image = vibrance_enhancer.enhance(5)

image.show()
enhanced_image.show()
