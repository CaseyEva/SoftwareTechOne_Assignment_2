from PIL import Image

#Open and show Image
image = Image.open("'\folder_name\img_name.jpg'")

#Get basic Info
print(image.size)
print(image.filename)
print(image.format)

image = image.transpose(Image.Transpose.ROTATE_90)
image.show()

img_rotated = image.rotate(30)
img_rotated.save('img_rotated1.png', 'png')
